import { Product, Task, Metric } from '../types';

export const products: Product[] = [
  {
    id: '1',
    name: 'TaskFlow Pro',
    description: 'Advanced project management platform with AI-powered insights',
    status: 'development',
    progress: 75,
    team: [
      { id: '1', name: 'Sanjai', role: 'Product Manager', avatar: 'https://images.pexels.com/photos/3760263/pexels-photo-3760263.jpeg?w=150' },
      { id: '2', name: 'Alex Chen', role: 'Frontend Developer', avatar: 'https://images.pexels.com/photos/3777943/pexels-photo-3777943.jpeg?w=150' },
      { id: '3', name: 'Maria Rodriguez', role: 'Backend Developer', avatar: 'https://images.pexels.com/photos/3785079/pexels-photo-3785079.jpeg?w=150' },
    ],
    lastUpdated: '2025-01-08',
    nextMilestone: 'Beta Release',
    tech: ['React', 'Node.js', 'PostgreSQL', 'TypeScript'],
    metrics: {
      users: 1250,
      revenue: 25000,
      performance: 94,
    },
  },
  {
    id: '2',
    name: 'DataViz Dashboard',
    description: 'Real-time analytics dashboard for business intelligence',
    status: 'testing',
    progress: 90,
    team: [
      { id: '1', name: 'Sanjai', role: 'Product Manager', avatar: 'https://images.pexels.com/photos/3760263/pexels-photo-3760263.jpeg?w=150' },
      { id: '4', name: 'David Kim', role: 'Data Engineer', avatar: 'https://images.pexels.com/photos/3760069/pexels-photo-3760069.jpeg?w=150' },
    ],
    lastUpdated: '2025-01-07',
    nextMilestone: 'Production Deploy',
    tech: ['Vue.js', 'Python', 'MongoDB', 'D3.js'],
    metrics: {
      users: 850,
      revenue: 18500,
      performance: 97,
    },
  },
  {
    id: '3',
    name: 'MobileFirst',
    description: 'Cross-platform mobile app for e-commerce solutions',
    status: 'planning',
    progress: 25,
    team: [
      { id: '1', name: 'Sanjai', role: 'Product Manager', avatar: 'https://images.pexels.com/photos/3760263/pexels-photo-3760263.jpeg?w=150' },
      { id: '5', name: 'Sarah Johnson', role: 'Mobile Developer', avatar: 'https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg?w=150' },
    ],
    lastUpdated: '2025-01-06',
    nextMilestone: 'Wireframe Approval',
    tech: ['React Native', 'Firebase', 'Stripe'],
    metrics: {
      users: 0,
      revenue: 0,
      performance: 0,
    },
  },
];

export const tasks: Task[] = [
  {
    id: '1',
    title: 'Implement user authentication',
    status: 'completed',
    priority: 'high',
    assignee: 'Alex Chen',
    dueDate: '2025-01-10',
    productId: '1',
  },
  {
    id: '2',
    title: 'Design dashboard wireframes',
    status: 'in-progress',
    priority: 'medium',
    assignee: 'Sanjai',
    dueDate: '2025-01-12',
    productId: '2',
  },
  {
    id: '3',
    title: 'Set up CI/CD pipeline',
    status: 'todo',
    priority: 'high',
    assignee: 'Maria Rodriguez',
    dueDate: '2025-01-15',
    productId: '1',
  },
];

export const metrics: Metric[] = [
  {
    label: 'Total Users',
    value: '2,100',
    change: 12.5,
    trend: 'up',
  },
  {
    label: 'Monthly Revenue',
    value: '$43,500',
    change: 8.2,
    trend: 'up',
  },
  {
    label: 'Active Projects',
    value: '3',
    change: 0,
    trend: 'stable',
  },
  {
    label: 'Team Productivity',
    value: '94%',
    change: -2.1,
    trend: 'down',
  },
];