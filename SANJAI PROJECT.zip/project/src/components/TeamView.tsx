import React from 'react';
import { Mail, Calendar, Award, Coffee } from 'lucide-react';
import { products } from '../data/sampleData';

export default function TeamView() {
  // Get all unique team members across products
  const allTeamMembers = products.reduce((acc, product) => {
    product.team.forEach(member => {
      if (!acc.find(m => m.id === member.id)) {
        acc.push(member);
      }
    });
    return acc;
  }, [] as any[]);

  // Get products for each team member
  const getTeamMemberProjects = (memberId: string) => {
    return products.filter(product => 
      product.team.some(member => member.id === memberId)
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Team Members</h1>
        <p className="text-gray-600">Manage your product development team</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {allTeamMembers.map((member) => {
          const memberProjects = getTeamMemberProjects(member.id);
          
          return (
            <div
              key={member.id}
              className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 hover:shadow-md transition-all duration-200"
            >
              <div className="flex items-center space-x-4 mb-6">
                <img
                  src={member.avatar}
                  alt={member.name}
                  className="w-16 h-16 rounded-full border-4 border-gray-100"
                />
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">{member.name}</h3>
                  <p className="text-gray-600">{member.role}</p>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center space-x-3 text-sm text-gray-600">
                  <Award className="w-4 h-4" />
                  <span>{memberProjects.length} Active Project{memberProjects.length !== 1 ? 's' : ''}</span>
                </div>

                <div className="flex items-center space-x-3 text-sm text-gray-600">
                  <Calendar className="w-4 h-4" />
                  <span>Available this week</span>
                </div>

                <div className="flex items-center space-x-3 text-sm text-gray-600">
                  <Coffee className="w-4 h-4" />
                  <span>9:00 AM - 6:00 PM PST</span>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-gray-200">
                <p className="text-sm font-medium text-gray-900 mb-2">Current Projects:</p>
                <div className="space-y-1">
                  {memberProjects.map((project) => (
                    <span
                      key={project.id}
                      className="inline-block bg-blue-50 text-blue-700 px-2 py-1 rounded text-xs mr-2 mb-1"
                    >
                      {project.name}
                    </span>
                  ))}
                </div>
              </div>

              <div className="mt-4 flex space-x-2">
                <button className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition-colors duration-200 flex items-center justify-center space-x-2">
                  <Mail className="w-4 h-4" />
                  <span>Message</span>
                </button>
                <button className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-2 px-4 rounded-lg transition-colors duration-200">
                  View Profile
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}