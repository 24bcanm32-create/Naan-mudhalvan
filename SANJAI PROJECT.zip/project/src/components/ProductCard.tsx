import React from 'react';
import { Calendar, Users, Code, ArrowRight } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onClick: () => void;
}

export default function ProductCard({ product, onClick }: ProductCardProps) {
  const getStatusColor = (status: Product['status']) => {
    switch (status) {
      case 'planning':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'development':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'testing':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'deployed':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'maintenance':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div
      onClick={onClick}
      className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 hover:shadow-lg hover:border-blue-300 transition-all duration-200 cursor-pointer group"
    >
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-xl font-semibold text-gray-900 group-hover:text-blue-700 transition-colors duration-200">
            {product.name}
          </h3>
          <p className="text-gray-600 mt-1">{product.description}</p>
        </div>
        <ArrowRight className="w-5 h-5 text-gray-400 group-hover:text-blue-600 transition-colors duration-200" />
      </div>

      <div className="flex items-center justify-between mb-4">
        <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(product.status)}`}>
          {product.status.charAt(0).toUpperCase() + product.status.slice(1)}
        </span>
        <span className="text-sm text-gray-600">{product.progress}% complete</span>
      </div>

      <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
        <div
          className="bg-gradient-to-r from-blue-500 to-indigo-600 h-2 rounded-full transition-all duration-300"
          style={{ width: `${product.progress}%` }}
        ></div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center space-x-2 text-sm text-gray-600">
          <Calendar className="w-4 h-4" />
          <span>Next: {product.nextMilestone}</span>
        </div>

        <div className="flex items-center space-x-2 text-sm text-gray-600">
          <Users className="w-4 h-4" />
          <div className="flex -space-x-1">
            {product.team.slice(0, 3).map((member) => (
              <img
                key={member.id}
                src={member.avatar}
                alt={member.name}
                className="w-6 h-6 rounded-full border-2 border-white"
              />
            ))}
            {product.team.length > 3 && (
              <div className="w-6 h-6 bg-gray-300 rounded-full border-2 border-white flex items-center justify-center">
                <span className="text-xs font-medium text-gray-700">+{product.team.length - 3}</span>
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-2 text-sm text-gray-600">
          <Code className="w-4 h-4" />
          <div className="flex flex-wrap gap-1">
            {product.tech.slice(0, 3).map((tech) => (
              <span
                key={tech}
                className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs"
              >
                {tech}
              </span>
            ))}
            {product.tech.length > 3 && (
              <span className="text-xs text-gray-500">+{product.tech.length - 3} more</span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}